These samples were sourced from https://voicemaker.in/

Settings:
* extra fast
* neural TTS
* Luna, Female

still need `<prosody rate='x-fast'>point</prosody>`