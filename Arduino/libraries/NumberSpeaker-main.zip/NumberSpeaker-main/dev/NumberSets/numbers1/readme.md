These were sourced from google pronounciation tool

e.g., https://www.google.com/search?q=pronounce+zero

Then shortened by manually editing the waveform to reduce pauses