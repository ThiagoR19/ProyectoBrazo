These samples were sourced from https://voicemaker.in/

Settings:
* extra fast
* standard TTS
* Kimberly, Female